package com.serena.air

import com.urbancode.air.CommandHelper
import org.apache.log4j.Logger

class ProcessHelper {
    private static final Logger logger = Logger.getLogger(ProcessHelper.class)

    public static def run(ProcessBuilder processBuilder, def errMsgSrc){
        run(processBuilder, errMsgSrc, null)
    }
    public static def run(ProcessBuilder processBuilder, def errMsgSrc, Closure resultHandler){
        def res =  CommandHelper.waitForProcess(processBuilder.start())

        //Result processing
        if(resultHandler != null){
            return resultHandler(res)
        } else {
            /* Error handling
             * Supported 3 ways of setting error message:
             *      one error string for all codes
             *      Map, Array or any other object with [] operator
             *      Closure { int/ProcessExecutionResult -> anyType }
             */
            if(res.exitCode != 0) {
                logger.error("Process returned with code: ${res.exitCode}")
                logger.error("StdOut= ${res.inputStream}")
                logger.error("StdErr= ${res.errorStream}")
                switch (true) {
                    case errMsgSrc instanceof String:
                        throw new StepFailedException(errMsgSrc as String)
                    case errMsgSrc instanceof Closure:
                        Closure closure = errMsgSrc
                        if(closure.parameterTypes.length > 0 && closure.parameterTypes[0] == Integer){
                            throw new StepFailedException(closure(res.exitCode))
                        } else {
                            throw new StepFailedException(closure(res))
                        }
                    default:
                        throw new StepFailedException(errMsgSrc[res.exitCode])
                }
            }
            return res
        }
    }
}
